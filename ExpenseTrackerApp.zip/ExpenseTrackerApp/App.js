import 'react-native-gesture-handler';
import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, SafeAreaView, Platform, StatusBar, Button } from 'react-native';
import { NavigationContainer, useIsFocused, useNavigationContainerRef } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { FontAwesome5, MaterialCommunityIcons, MaterialIcons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';


const categories = [
  { name: 'Food', icon: 'utensils', library: FontAwesome5, color: '#FFC107' },
  { name: 'Transport', icon: 'car', library: FontAwesome5, color: '#2196F3' },
  { name: 'Shopping', icon: 'shopping-bag', library: FontAwesome5, color: '#E91E63' },
  { name: 'Fun', icon: 'gamepad-variant', library: MaterialCommunityIcons, color: '#4CAF50' },
  { name: 'Health', icon: 'heartbeat', library: FontAwesome5, color: '#F44336' },
  { name: 'Other', icon: 'dots-horizontal', library: MaterialCommunityIcons, color: '#9E9E9E' },
];


const getTotalSpent = async () => {
  const storedExpenses = await AsyncStorage.getItem('expenses');
  const expenses = storedExpenses ? JSON.parse(storedExpenses) : [];
  return expenses.reduce((sum, exp) => sum + exp.amount, 0);
};

const formatDateString = (date) => {
  if (!(date instanceof Date) || isNaN(date)) {
    return formatDateString(new Date());
  }
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const year = date.getFullYear();
  return `${month}/${day}/${year}`;
};


const AppHeader = ({ totalSpent }) => {
  return (
    <View style={styles.headerContainer}>
      <Text style={styles.headerTitle}>ExpenseTracker</Text>
      <View style={styles.headerRight}>
        <View>
          <Text style={styles.totalSpentLabel}>Total Spent</Text>
          <Text style={styles.totalSpentAmount}>₹{totalSpent.toFixed(2)}</Text>
        </View>
        <TouchableOpacity style={styles.profileIconContainer}>
          <FontAwesome5 name="wallet" size={16} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const NavigationTabs = ({ navigationRef, activeRoute }) => {
  return (
    <View style={styles.navTabsContainer}>
      <TouchableOpacity
        style={[styles.navTab, activeRoute === 'AddExpense' && styles.navTabActive]}
        onPress={() => navigationRef.navigate('AddExpense')}
      >
        <MaterialIcons name="add" size={20} color="#fff" />
        <Text style={styles.navTabText}>Add Expense</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.navTab, activeRoute === 'ViewExpenses' && styles.navTabActive]}
        onPress={() => navigationRef.navigate('ViewExpenses')}
      >
        <MaterialIcons name="list" size={20} color="#fff" />
        <Text style={styles.navTabText}>View Expenses</Text>
      </TouchableOpacity>
    </View>
  );
};

const AddExpenseScreen = ({ onExpenseAdded }) => {
  const [amount, setAmount] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [date, setDate] = useState(new Date());
  const [note, setNote] = useState('');
  const [showDatePicker, setShowDatePicker] = useState(false);


  const handleAddExpense = async () => {
    if (!selectedCategory || !amount) {
      alert('Please enter an amount and select a category.');
      return;
    }
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      alert('Please enter a valid positive amount.');
      return;
    }


    const newExpense = {
      id: Date.now().toString(),
      amount: parsedAmount,
      category: selectedCategory,
      date: formatDateString(date),
      note: note.trim() || selectedCategory,
      timestamp: new Date().toISOString(),
    };

    try {
      const existingExpenses = await AsyncStorage.getItem('expenses');
      const expenses = existingExpenses ? JSON.parse(existingExpenses) : [];
      expenses.unshift(newExpense);
      await AsyncStorage.setItem('expenses', JSON.stringify(expenses));

      setAmount('');
      setSelectedCategory('');
      setNote('');
      setDate(new Date());
      alert('Expense added successfully!');
      onExpenseAdded();
    } catch (error) {
      console.error('Error saving expense:', error);
      alert('Failed to add expense.');
    }
  };

  const onDateChange = (event, selectedDate) => {
    setShowDatePicker(Platform.OS === 'ios');
    if (event.type === 'set') {
      const currentDate = selectedDate || date;
      setDate(currentDate);
      if (Platform.OS === 'android') {
        setShowDatePicker(false);
      }
    } else {
      if (Platform.OS === 'android') {
        setShowDatePicker(false);
      }
    }
  };

  const showDatepicker = () => {
    setShowDatePicker(true);
  };

  return (
    <View style={styles.screenContainer}>
      <View style={styles.formContainer}>
        <Text style={styles.label}>Amount</Text>
        <View style={styles.amountInputContainer}>
          <Text style={styles.dollarSign}>₹</Text>
          <TextInput
            style={styles.amountInput}
            value={amount}
            onChangeText={setAmount}
            placeholder="0.00"
            placeholderTextColor="#A1A1AA"
            keyboardType="numeric"
          />
        </View>
        <Text style={styles.label}>Category</Text>
        <View style={styles.categoryContainer}>
          {categories.map((cat) => {
            const IconComponent = cat.library;
            return (
              <TouchableOpacity
                key={cat.name}
                style={[styles.categoryButton, selectedCategory === cat.name && styles.selectedCategory]}
                onPress={() => setSelectedCategory(cat.name)}
              >
                <IconComponent name={cat.icon} size={24} color="#fff" />
                <Text style={styles.categoryText}>{cat.name}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
        <Text style={styles.label}>Date</Text>
        <TouchableOpacity style={styles.inputWrapper} onPress={showDatepicker}>
          <Text style={[styles.input, { paddingVertical: 15 }]}>{formatDateString(date)}</Text>
          <MaterialIcons name="calendar-today" size={20} color="#A1A1AA" style={styles.inputIcon} />
        </TouchableOpacity>
        {showDatePicker && (
          <DateTimePicker
            value={date}
            mode="date"
            display={Platform.OS === 'ios' ? 'inline' : 'calendar'}
            onChange={onDateChange}
            maximumDate={new Date()}
            themeVariant="dark"
          />
        )}
        <Text style={styles.label}>Note (Optional)</Text>
        <View style={styles.inputWrapper}>
          <TextInput
            style={[styles.input, styles.noteInput]}
            value={note}
            onChangeText={setNote}
            placeholder="Add a note..."
            placeholderTextColor="#A1A1AA"
            multiline
          />
        </View>
      </View>
      <TouchableOpacity style={styles.addButton} onPress={handleAddExpense}>
        <MaterialIcons name="add" size={24} color="#fff" />
        <Text style={styles.addButtonText}>Add Expense</Text>
      </TouchableOpacity>
    </View>
  );
};

const ViewExpensesScreen = ({ onDataNeeded }) => {
  const [expenses, setExpenses] = useState([]);
  const [thisMonth, setThisMonth] = useState(0);
  const [lastMonth, setLastMonth] = useState(0);
  const isFocused = useIsFocused();

  useEffect(() => {
    if (isFocused) {
      const loadExpenses = async () => {
        try {
          onDataNeeded();
          const storedExpenses = await AsyncStorage.getItem('expenses');
          const parsedExpenses = storedExpenses ? JSON.parse(storedExpenses) : [];

          const sortedExpenses = parsedExpenses.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
          setExpenses(sortedExpenses);

          const currentDate = new Date();
          const currentMonth = currentDate.getMonth();
          const currentYear = currentDate.getFullYear();

          let thisMonthTotal = 0;
          let lastMonthTotal = 0;

          const lastMonthDate = new Date();
          lastMonthDate.setMonth(currentMonth - 1);
          const lastMonthValue = lastMonthDate.getMonth();
          const lastMonthYear = lastMonthDate.getFullYear();

          sortedExpenses.forEach(exp => {
            const expenseDate = new Date(exp.date);
            if (isNaN(expenseDate.getTime())) return;

            const expenseMonth = expenseDate.getMonth();
            const expenseYear = expenseDate.getFullYear();

            if (expenseMonth === currentMonth && expenseYear === currentYear) {
              thisMonthTotal += exp.amount;
            } else if (expenseMonth === lastMonthValue && expenseYear === lastMonthYear) {
              lastMonthTotal += exp.amount;
            }
          });

          setThisMonth(thisMonthTotal);
          setLastMonth(lastMonthTotal);

        } catch (error) {
          console.error('Error loading expenses:', error);
        }
      };
      loadExpenses();
    }
  }, [isFocused, onDataNeeded]);

  const renderExpenseItem = ({ item }) => {
    const categoryInfo = categories.find((c) => c.name === item.category) || categories.find(c => c.name === 'Other');
    const IconComponent = categoryInfo.library;
    return (
      <View style={styles.expenseItem}>
        <View style={[styles.expenseIconContainer, { backgroundColor: categoryInfo.color }]}>
          <IconComponent name={categoryInfo.icon} size={20} color="#fff" />
        </View>
        <View style={styles.expenseDetails}>
          <Text style={styles.expenseTitle}>{item.note}</Text>
          <Text style={styles.expenseDate}>{item.date}</Text>
        </View>
        <Text style={styles.expenseAmount}>-₹{item.amount.toFixed(2)}</Text>
      </View>
    );
  };

  return (
    <View style={styles.screenContainer}>
      <View style={styles.monthlySummaryCard}>
        <View style={styles.monthlyBox}>
          <Text style={styles.monthlyLabel}>This Month</Text>
          <Text style={styles.monthlyAmount}>₹{thisMonth.toFixed(2)}</Text>
        </View>
        <View style={styles.monthlySeparator} />
        <View style={styles.monthlyBox}>
          <Text style={styles.monthlyLabel}>Last Month</Text>
          <Text style={styles.monthlyAmount}>₹{lastMonth.toFixed(2)}</Text>
        </View>
      </View>
      <Text style={styles.recentExpensesLabel}>Recent Expenses</Text>
      {expenses.length === 0 ? (
        <Text style={styles.noExpensesText}>No expenses yet. Add one!</Text>
      ) : (
        <FlatList
          data={expenses}
          keyExtractor={(item) => item.id}
          renderItem={renderExpenseItem}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
};

const Stack = createStackNavigator();

const App = () => {
  const [totalSpent, setTotalSpent] = useState(0);
  const navigationRef = useNavigationContainerRef();
  const [activeRoute, setActiveRoute] = useState('AddExpense');

  const handleUpdate = async () => {
    const total = await getTotalSpent();
    setTotalSpent(total);
  };

  useEffect(() => {
    handleUpdate();
  }, []);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <AppHeader totalSpent={totalSpent} />
        <NavigationTabs navigationRef={navigationRef} activeRoute={activeRoute} />
        <NavigationContainer
          ref={navigationRef}
          independent={true}
          onStateChange={() => {
            const currentRouteName = navigationRef.getCurrentRoute()?.name;
            if (currentRouteName) {
              setActiveRoute(currentRouteName);
            }
          }}
        >
          <Stack.Navigator
            initialRouteName="AddExpense"
            screenOptions={{ headerShown: false }}
          >
            <Stack.Screen name="AddExpense">
              {props => <AddExpenseScreen {...props} onExpenseAdded={handleUpdate} />}
            </Stack.Screen>
            <Stack.Screen name="ViewExpenses">
              {props => <ViewExpensesScreen {...props} onDataNeeded={handleUpdate} />}
            </Stack.Screen>
          </Stack.Navigator>
        </NavigationContainer>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#16171E',
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
  },
  container: {
    flex: 1,
    backgroundColor: '#16171E',
    paddingHorizontal: 20,
    paddingBottom: 10,
  },
  screenContainer: {
    flex: 1,
    backgroundColor: '#16171E',
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 10,
    paddingBottom: 20,
  },
  headerTitle: { color: '#fff', fontSize: 22, fontWeight: 'bold' },
  headerRight: { flexDirection: 'row', alignItems: 'center' },
  totalSpentLabel: { color: '#A1A1AA', fontSize: 12, textAlign: 'right' },
  totalSpentAmount: { color: '#E65B65', fontSize: 18, fontWeight: 'bold' },
  profileIconContainer: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#6366F1', justifyContent: 'center', alignItems: 'center', marginLeft: 15 },
  navTabsContainer: { flexDirection: 'row', backgroundColor: '#2D2D44', borderRadius: 12, padding: 4, marginBottom: 20 },
  navTab: { flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingVertical: 12, borderRadius: 10 },
  navTabActive: { backgroundColor: '#6366F1' },
  navTabText: { color: '#fff', fontSize: 14, fontWeight: 'bold', marginLeft: 8 },
  formContainer: { flex: 1 },
  label: { color: '#A1A1AA', fontSize: 14, marginBottom: 8, marginTop: 15 },
  amountInputContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#2D2D44', borderRadius: 10, paddingHorizontal: 15, marginBottom: 10 },
  dollarSign: { color: '#A1A1AA', fontSize: 24, marginRight: 10 },
  amountInput: { flex: 1, color: '#fff', fontSize: 24, fontWeight: 'bold', paddingVertical: 15 },
  categoryContainer: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 10, marginBottom: -55 },
  categoryButton: { backgroundColor: '#2D2D44', width: '31%', aspectRatio: 1, borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
  selectedCategory: { backgroundColor: '#6366F1' },
  categoryText: { color: '#fff', marginTop: 8, fontSize: 12 },
  inputWrapper: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#2D2D44', borderRadius: 10, marginBottom: 10 },
  input: { flex: 1, color: '#fff', padding: 15, fontSize: 16 },
  inputIcon: { paddingHorizontal: 15 },
  noteInput: { height: 80, textAlignVertical: 'top' },
  addButton: { backgroundColor: '#6366F1', flexDirection: 'row', justifyContent: 'center', alignItems: 'center', padding: 18, borderRadius: 12, marginTop: 10 },
  addButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold', marginLeft: 8 },
  monthlySummaryCard: { flexDirection: 'row', backgroundColor: '#2D2D44', borderRadius: 12, padding: 20, marginBottom: 20, marginTop: 10, alignItems: 'center' },
  monthlyBox: { flex: 1, alignItems: 'flex-start' },
  monthlyLabel: { color: '#A1A1AA', fontSize: 14 },
  monthlyAmount: { color: '#fff', fontSize: 20, fontWeight: 'bold', marginTop: 4 },
  monthlySeparator: { width: 1, height: '80%', backgroundColor: '#4A4A6A', marginHorizontal: 15 },
  recentExpensesLabel: { color: '#A1A1AA', fontSize: 16, fontWeight: 'bold', marginBottom: 15 },
  expenseItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#2D2D44', padding: 15, borderRadius: 12, marginBottom: 10 },
  expenseIconContainer: { width: 40, height: 40, borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginRight: 15 },
  expenseDetails: { flex: 1 },
  expenseTitle: { color: '#fff', fontSize: 16, fontWeight: '500' },
  expenseDate: { color: '#A1A1AA', fontSize: 12, marginTop: 4 },
  expenseAmount: { color: '#E65B65', fontSize: 16, fontWeight: 'bold' },
  noExpensesText: {
    color: '#A1A1AA',
    textAlign: 'center',
    marginTop: 40,
    fontSize: 16,
  }
});

export default App;